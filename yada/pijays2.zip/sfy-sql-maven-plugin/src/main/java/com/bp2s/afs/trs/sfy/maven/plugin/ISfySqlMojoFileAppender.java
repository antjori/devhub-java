package com.bp2s.afs.trs.sfy.maven.plugin;

/**
 * Interface that abstracts the behavior of appending the header and footer of
 * file processing.
 */
public interface ISfySqlMojoFileAppender {

	/**
	 * Creates a header to append to a specific SQL file.
	 * 
	 * @param fileName
	 *            the file name
	 * @return the string header to append
	 */
	String appendHeader(String fileName);

	/**
	 * Creates a footer to append to a specific SQL file.
	 * 
	 * @param fileName
	 *            the file name
	 * @return the string footer to append
	 */
	String appendFooter(String fileName);
}
