package com.bp2s.afs.trs.sfy.maven.plugin;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.project.MavenProject;

/**
 * The SFY SQL Maven plug-in.
 */
@Mojo(name = "build-sql")
public class SfySqlMojo extends AbstractMojo {

	@Parameter(defaultValue = "${project}", required = true, readonly = true)
	private MavenProject project;

	@Parameter(required = true, readonly = true)
	private String sourceDir;

	@Parameter(required = true, readonly = true)
	private List<String> databases;

	@Parameter(required = true, readonly = true)
	private DatabaseEngineType databaseEngineType;

	private ISfySqlMojoFileAppender appender;

	/**
	 * The file filter.
	 */
	private static FileFilter filter = new FileFilter() {

		@Override
		public boolean accept(final File file) {
			String fileName = file.getName().toLowerCase();

			return fileName.endsWith(".pro") || fileName.endsWith(".sql");
		}
	};

	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		appender = SfySqlMojoFileAppenderFactory.getInstance().getAppender(databaseEngineType);

		String changesDir = project.getBasedir().getPath() + "/" + sourceDir + "/%s/changes/";

		for (String database : databases) {
			processSequentialFiles(changesDir, database);

			processNonSequentialFiles(changesDir, database);
		}
	}

	/**
	 * Processes the directory that contains the list of sequential files.
	 * 
	 * @param changesDir
	 *            the directory containing the changes
	 * @param database
	 *            the database engine type {@link DatabaseEngineType}
	 */
	private void processSequentialFiles(final String changesDir, final String database) {
		String sequentialDir = String.format(changesDir, database) + "sequential";

		// validates the existence of directory sequential
		if (!dirExists(sequentialDir)) {
			getLog().warn("Directory \"" + sequentialDir + "\" not found on. Skipping its process");

			return;
		}

		List<String> content = gatherContent(sequentialDir);

		// validates if any files were processed
		if (content.isEmpty()) {
			getLog().warn("No files were found to process");

			return;
		}

		// creates target if not exists
		String targetDir = project.getBuild().getDirectory();

		createsTargetIfNotExists(targetDir);

		// create new file on target
		Path target = Paths.get(targetDir + "/" + project.getBuild().getFinalName() + "-" + database + ".sql");

		try {
			Files.write(target, content, Charset.defaultCharset());
		} catch (IOException ioe) {
			getLog().error("An error occurred while trying to write all the contents to a single file", ioe);
		}
	}

	/**
	 * Gathers the content of all files present on the sequential folder of the
	 * changes directory.
	 * 
	 * @param directory
	 *            the sequential folder directory path
	 * @return a list of strings representing the content of all files present
	 *         on the sequential folder of the changes directory
	 */
	private List<String> gatherContent(final String sequentialDir) {
		final List<String> content = new ArrayList<>();
		List<File> files = Arrays.asList((new File(sequentialDir)).listFiles(filter));

		if ((files != null) && !files.isEmpty()) {

			Collections.sort(files);

			// gathers the content of all files
			for (File file : files) {
				content.add(appender.appendHeader(file.getName()));

				try {
					content.addAll(Files.readAllLines(file.toPath(), Charset.forName("Cp1252")));
				} catch (IOException e) {
					getLog().error("An error occurred while reading all lines from file " + file.getName()
							+ " using trying Cp1252", e);
				}

				content.add(appender.appendFooter(file.getName()));
				content.add("\n");
			}
		}

		return content;
	}

	/**
	 * Processes the non-sequential folder of the changes directory.
	 * 
	 * @param changesDir
	 *            the changes directory path
	 * @param database
	 *            the database type
	 */
	private void processNonSequentialFiles(final String changesDir, final String database) {
		String nonSequentialDir = String.format(changesDir, database) + "non-sequential";

		// validates the existence of directory non-sequential
		if (!dirExists(nonSequentialDir)) {
			getLog().warn("Directory \"" + nonSequentialDir + "\" not found. Skipping its process");

			return;
		}

		List<File> files = Arrays.asList((new File(nonSequentialDir)).listFiles(filter));

		// creates target if not exists
		String targetDir = project.getBuild().getDirectory();

		createsTargetIfNotExists(targetDir);

		for (File file : files) {
			try {
				Files.copy(file.toPath(), Paths.get(
						targetDir + "/" + project.getBuild().getFinalName() + "-" + database + "-" + file.getName()));
			} catch (IOException ioe) {
				getLog().error("An error occurred while trying to copy " + file.getName() + " to target directory",
						ioe);
			}
		}
	}

	/**
	 * Validates if a specific directory exists.
	 * 
	 * @param dir
	 *            the directory to validate
	 * @return true if the directory exists; false otherwise
	 */
	private boolean dirExists(final String dir) {
		return Paths.get(dir).toFile().exists();
	}

	/**
	 * Creates target directory if it does not exist.
	 *
	 * @param targetDir
	 *            the path to the target directory
	 */
	private void createsTargetIfNotExists(final String targetDir) {
		// checks the existence of target and creates it if not exists
		if (!dirExists(targetDir)) {
			try {
				Files.createDirectories(Paths.get(targetDir));
			} catch (IOException ioe) {
				getLog().error("An error occurred while trying to create target directory", ioe);
			}
		}
	}
}
