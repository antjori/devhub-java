package com.bp2s.afs.trs.sfy.maven.plugin;

/**
 * Factory class that provides the file appenders for the Software Factory SQL
 * mojo.
 */
public final class SfySqlMojoFileAppenderFactory {

	private static volatile SfySqlMojoFileAppenderFactory instance;

	private SfySqlMojoFileAppenderFactory() {
		// preventing object instantiation from outside
	}

	/**
	 * Gets this class singleton instance.
	 * 
	 * @return this class singleton instance
	 */
	public static SfySqlMojoFileAppenderFactory getInstance() {
		if (instance == null) {
			synchronized (SfySqlMojoFileAppenderFactory.class) {
				if (instance == null) {
					instance = new SfySqlMojoFileAppenderFactory();
				}
			}
		}

		return instance;
	}

	/**
	 * Attains the Software Factory SQL file appender.
	 * 
	 * @param type
	 *            the database engine type
	 * @return the Software Factory SQL file appender
	 */
	public ISfySqlMojoFileAppender getAppender(final DatabaseEngineType type) {
		ISfySqlMojoFileAppender appender = null;

		switch (type) {
		case ORACLE:
			appender = new OracleFileAppender();
			break;
		case SYBASE:
			appender = new SybaseFileAppender();
			break;
		default:
			break;
		}

		return appender;
	}
}
