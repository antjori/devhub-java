package com.bp2s.afs.trs.sfy.maven.plugin;

/**
 * Enumeration that defines the SQL database engine type.
 */
public enum DatabaseEngineType {

	ORACLE, SYBASE
}
