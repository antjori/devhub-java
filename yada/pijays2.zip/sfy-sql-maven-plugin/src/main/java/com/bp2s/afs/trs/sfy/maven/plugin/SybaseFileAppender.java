package com.bp2s.afs.trs.sfy.maven.plugin;

/**
 * The Sybase database engine file appender.
 */
public final class SybaseFileAppender implements ISfySqlMojoFileAppender {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String appendHeader(final String fileName) {
		return "print('>>> entering " + fileName + " <<<')";
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String appendFooter(final String fileName) {
		return "print('>>> leaving " + fileName + " <<<')";
	}

}
