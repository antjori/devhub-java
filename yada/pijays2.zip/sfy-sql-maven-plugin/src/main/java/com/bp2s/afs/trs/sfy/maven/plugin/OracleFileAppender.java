package com.bp2s.afs.trs.sfy.maven.plugin;

/**
 * The Oracle database engine file appender.
 */
public final class OracleFileAppender implements ISfySqlMojoFileAppender {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String appendHeader(final String fileName) {
		return "prompt >>> entering " + fileName + " <<<";
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String appendFooter(final String fileName) {
		return "prompt >>> leaving " + fileName + " <<<";
	}

}
