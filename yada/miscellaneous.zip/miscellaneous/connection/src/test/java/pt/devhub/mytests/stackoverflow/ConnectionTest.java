package pt.devhub.mytests.stackoverflow;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.Test;

public class ConnectionTest {

	@Test
	public void isValid() throws SQLException {
		MyConnection myConn = new MyConnection();
		Connection conn = myConn.getConnection();
        assertTrue(conn.isValid(0));
        conn.close();
        assertFalse(conn.isValid(0));
	}
}
