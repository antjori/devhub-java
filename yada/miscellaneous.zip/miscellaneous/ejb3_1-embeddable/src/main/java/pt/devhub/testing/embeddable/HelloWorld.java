package pt.devhub.testing.embeddable;

import javax.ejb.Stateless;

@Stateless
public class HelloWorld {
	public String hello(String message) {
		return "Hello " + message;
	}
}
