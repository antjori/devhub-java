package pt.devhub.example.javaee.fullstack.ejb;

import javax.ejb.Stateless;

@Stateless
public class MyEnterpriseJavaBean implements MyEnterpriseJavaBeanInterface {

}
