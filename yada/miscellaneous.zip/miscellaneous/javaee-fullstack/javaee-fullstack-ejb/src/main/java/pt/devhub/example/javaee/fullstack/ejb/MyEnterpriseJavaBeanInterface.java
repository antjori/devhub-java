package pt.devhub.example.javaee.fullstack.ejb;

import javax.ejb.Remote;

@Remote
public interface MyEnterpriseJavaBeanInterface {

}
