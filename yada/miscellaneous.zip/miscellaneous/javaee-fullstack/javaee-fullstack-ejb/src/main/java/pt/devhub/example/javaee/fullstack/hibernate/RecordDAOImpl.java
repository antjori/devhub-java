package pt.devhub.example.javaee.fullstack.hibernate;

import javax.inject.Inject;

import org.hibernate.Session;

import pt.devhub.example.javaee.fullstack.hibernate.ORMSessionFactory.ORMType;

public class RecordDAOImpl implements RecordDAO {

	@Inject
	@ORMSessionFactory(ORMType.HIBERNATE)
	private MySessionFactory mySessionFactory;

	@Override
	public String getRecord(Long id) {
		String value = null;
		Session session = mySessionFactory.getSessionFactory().openSession();

		try {
			session.beginTransaction();

			// do some transactional stuff

			session.getTransaction().commit();

		} catch (Exception e) {
			session.getTransaction().rollback();
		} finally {
			session.close();
		}

		return value;
	}
}
