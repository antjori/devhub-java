package pt.devhub.example.javaee.fullstack.hibernate;

import org.hibernate.SessionFactory;

public interface MySessionFactory {

	public SessionFactory getSessionFactory();

	public void shutdownSessionFactory();
}
