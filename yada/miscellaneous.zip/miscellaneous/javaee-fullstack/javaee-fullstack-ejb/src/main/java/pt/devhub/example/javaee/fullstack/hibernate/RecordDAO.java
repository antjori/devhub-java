package pt.devhub.example.javaee.fullstack.hibernate;

public interface RecordDAO {

	public String getRecord(Long id);
}
