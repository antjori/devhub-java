package pt.devhub.example.javaee.fullstack.hibernate;

public class ORMSessionFactoryProducer {

//	@Produces
//	@ORMSessionFactory(ORMType.HIBERNATE)
//	public MySessionFactory getHibernateSessionFactory() {
//		return new HibernateSessionFactory(new StandardServiceRegistryBuilder());
//	}
//
//	@Produces
//	@ORMSessionFactory(ORMType.ECLIPSELINK)
//	public MySessionFactory getEclipselinkSessionFactory() {
//		return null;
//	}
}
