package pt.devhub.example.javaee.fullstack.hibernate;

import javax.ejb.Remote;

@Remote
public interface HibernateBean {

	public void doSomething();
}
