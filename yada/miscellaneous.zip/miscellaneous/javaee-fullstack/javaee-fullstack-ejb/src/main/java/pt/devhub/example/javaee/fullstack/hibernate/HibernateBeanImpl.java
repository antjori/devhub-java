package pt.devhub.example.javaee.fullstack.hibernate;

import javax.ejb.Stateless;
import javax.inject.Inject;

@Stateless
public class HibernateBeanImpl implements HibernateBean {

	@Inject
	private RecordDAO recordDAO;
	
	@Override
	public void doSomething() {
		System.out.println("Doing something");
		recordDAO.getRecord(1L);
		System.out.println("Finished doing something");
	}

}
