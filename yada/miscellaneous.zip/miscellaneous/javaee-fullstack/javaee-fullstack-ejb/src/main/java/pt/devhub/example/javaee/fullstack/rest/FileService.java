package pt.devhub.example.javaee.fullstack.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@Path("/fileservice")
public class FileService {

	@POST
	@Path("/path")
	@Consumes("application/xml")
	public Response getFilePath(FileRequest fileRequest) {

	    System.out.println("....." + fileRequest.client);

	    return Response.ok().build();
	}

}
