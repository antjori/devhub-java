package pt.devhub.example.javaee.fullstack.rest;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "fileDetails")
public class FileRequest {

	@XmlElement
	public String path;

	@XmlElement
	public String client;

	public FileRequest() {}

}
