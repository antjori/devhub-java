package pt.devhub.example.javaee.fullstack;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;

import pt.devhub.example.javaee.fullstack.hibernate.HibernateBean;

public class FullStackMain {

	public static void main(String[] args) throws Exception {
		// lookupHibernateBean();

		// callJaxbRestService();
	}

	protected static void lookupHibernateBean() throws NamingException {
		Hashtable<String, Object> jndiProperties = new Hashtable<>();
		jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
		jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
		jndiProperties.put(Context.PROVIDER_URL, "http-remoting://127.0.0.1:8080");
		jndiProperties.put("jboss.naming.client.ejb.context", true);

		Context context = new InitialContext(jndiProperties);

		HibernateBean hb = (HibernateBean) context.lookup(
				"example/myejbjndi/HibernateBeanImpl!pt.devhub.example.javaee.fullstack.hibernate.HibernateBean");
		hb.doSomething();
	}

	protected static void callJaxbRestService() {
		URI uri = null;

		try {
			uri = new URI("http://localhost:8080/javaee-fullstack/services/fileservice/path");
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Client client = ClientBuilder.newClient();

		String xml = "<fileDetails> " + "<path>usr/test/a.pdf</path>" + "<client>abc</client>" + "</fileDetails>";

//		FileRequest request = new FileRequest();
//		request.setPath("usr/test/a.pdf");
//		request.setClient("abc");

		Response response = client.target(uri).request().post(Entity.xml(xml));
				//.request(MediaType.APPLICATION_XML).post(Entity.entity(request, MediaType.APPLICATION_XML), Response.class);
		System.out.println("Request posted :" + response.getAllowedMethods());
		System.out.println("Request posted, response status :" + response.getStatus());
	}

}
