package pt.devhub.example.javaee.fullstack.hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import pt.devhub.example.javaee.fullstack.hibernate.ORMSessionFactory.ORMType;

@ORMSessionFactory(ORMType.HIBERNATE)
public class HibernateSessionFactory extends AbstractSessionFactory {

//	private StandardServiceRegistryBuilder ssrb;
//
//	public HibernateSessionFactory(StandardServiceRegistryBuilder ssrb) {
//		this.ssrb = ssrb;
//	}

	@Override
	protected SessionFactory buildSessionFactory() {
		try {

			Configuration configuration = new Configuration();
			configuration.configure("hibernate.cfg.xml");

//			ServiceRegistry sr = ssrb.applySettings(configuration.getProperties())
//					.build();
			ServiceRegistry sr = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties())
					.build();
			sessionFactory = configuration.buildSessionFactory(sr);

			return sessionFactory;

		} catch (Exception ex) {
			throw ex;
		}
	}

}
