package pt.devhub.example.javaee.fullstack;

import java.io.FileInputStream;
import java.net.URI;
import java.net.URISyntaxException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataOutput;

public class FullStackMain {

	public static void main(String[] args) throws Exception {
		// callRestServiceGET();

		// callRestServicePOST();

		// callRest();

		callUpload();
	}

	protected static void callRestServiceGET() {
		URI uri = null;

		try {
			uri = new URI("http://localhost:8080/javaee-fullstack-war-0.0.1-SNAPSHOT/rest/fileservice/someClientId");
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		Client client = ClientBuilder.newClient();

		Response response = client.target(uri).request().get();
		System.out.println("GET sended, response status: " + response.getStatus());
	}

	protected static void callRestServicePOST() {
		URI uri = null;

		try {
			uri = new URI("http://localhost:8080/javaee-fullstack-war-0.0.1-SNAPSHOT/rest/fileservice/file");
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		Client client = ClientBuilder.newClient();

		String xml = "<file><id>1234567</id><name>abc</name></file>";

		Response response = client.target(uri).request().post(Entity.xml(xml));
		System.out.println("POST sended, response status: " + response.getStatus());
	}

	protected static void callRest() {
		try {
			HttpClient client = HttpClientBuilder.create().build();

			HttpPost request = new HttpPost("http://localhost:8080/components");

			// request.setEntity(new StringEntity("executing post operation"));

			request.setHeader("Accept", MediaType.APPLICATION_XML);
			request.setHeader("Content-type", MediaType.MULTIPART_FORM_DATA);

			HttpResponse response = client.execute(request);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected static void callUpload() {
		Client client = null;
		WebTarget webTarget = null;
		Builder builder = null;
		MultipartFormDataOutput multipartFormDataOutput = null;
		GenericEntity<MultipartFormDataOutput> genericEntity = null;
		Response response = null;
		int responseCode;
		String responseMessageFromServer = null;
		String responseString = null;

		try {
			// invoke service after setting necessary parameters
			client = ClientBuilder.newClient();
			webTarget = client
					.target("http://localhost:8080/javaee-fullstack-war-0.0.1-SNAPSHOT/rest/fileservice/upload");
			client.property("Content-Type", MediaType.MULTIPART_FORM_DATA);
			builder = webTarget.request();

			// set file upload values
			multipartFormDataOutput = new MultipartFormDataOutput();
			multipartFormDataOutput.addFormData("uploadedFile",
					new FileInputStream(
							"C:\\bp2s\\work\\projects\\bp2s_workspace\\hubble\\hubble-logic\\src\\test\\resources\\123456_20160101000000_TRS.map"),
					MediaType.MULTIPART_FORM_DATA_TYPE, "123456_20160101000000_TRS.map");
			genericEntity = new GenericEntity<MultipartFormDataOutput>(multipartFormDataOutput) {
			};

			// invoke service
			response = builder.post(Entity.entity(genericEntity, MediaType.MULTIPART_FORM_DATA_TYPE));

			// get response code
			responseCode = response.getStatus();
			System.out.println("Response code: " + responseCode);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed with HTTP error code : " + responseCode);
			}

			// get response message
			responseMessageFromServer = response.getStatusInfo().getReasonPhrase();
			System.out.println("ResponseMessageFromServer: " + responseMessageFromServer);

			// get response string
			responseString = response.readEntity(String.class);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			// release resources, if any
			if (response != null) {
				response.close();
			}

			if (client != null) {
				client.close();				
			}
		}

		System.out.println(responseString);
	}
}
