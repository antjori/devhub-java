package pt.devhub.example.javaee.fullstack.filter;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

public class MyPojo {

	private List<String> members;
	private String name;

	@PostConstruct
	public void initialize() {
		members = new ArrayList<String>();
		members.add("Ian Schultz");
		members.add("Diane Reyes");
		name = "Computer Science";
	}

	public List<String> getMembers() {
		return members;
	}

	public String getName() {
		return name;
	}
}
