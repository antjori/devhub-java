package pt.devhub.example.javaee.fullstack.filter;

import java.io.IOException;

import javax.annotation.Priority;
import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.ext.Provider;

@Priority(value = 2)
@Provider
@Singleton
public class MyFilter implements ContainerRequestFilter {

	@Inject
	private MyPojo myPojo;

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		System.out.println(myPojo.getName());
	}

}
