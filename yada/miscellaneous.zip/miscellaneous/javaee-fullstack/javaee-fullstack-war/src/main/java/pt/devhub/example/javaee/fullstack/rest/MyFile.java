package pt.devhub.example.javaee.fullstack.rest;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="file")
public class MyFile {

	@XmlElement
	public String id;

	@XmlElement
	public String name;

	public MyFile() {}
}
