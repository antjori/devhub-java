package pt.devhub.example.javaee.fullstack.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

@Path("/fileservice")
public class FileService {

	@GET
	@Path("/{id}")
	@Produces("text/html")
	public Response getFileId(@PathParam("id") String fileId) {
		System.out.println(fileId);

		return Response.ok().entity(fileId).build();
	}

	@POST
	@Path("/file")
	@Consumes(MediaType.APPLICATION_XML)
	public Response createFile(MyFile myFile) {
		System.out.println(myFile.id);

		return Response.ok().build();
	}

	@POST
    @Path("/upload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response uploadPdfFile(MultipartFormDataInput multipartFormDataInput) {
		System.out.println("....." + multipartFormDataInput.toString());

	    return Response.ok().build();
	}
}
