package com.example;

import javax.ejb.Stateless;

@Stateless
public class MyEjb {

}
