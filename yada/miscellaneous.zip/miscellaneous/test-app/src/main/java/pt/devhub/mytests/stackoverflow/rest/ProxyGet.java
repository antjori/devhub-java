package pt.devhub.mytests.stackoverflow.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.util.EntityUtils;
import org.glassfish.jersey.apache.connector.ApacheConnectorProvider;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;

public class ProxyGet {

	static String AccessToken = "xxxx";
	static String AccessSecret = "xxxx";
	static String ConsumerKey = "xxxx";
	static String ConsumerSecret = "xxxx";

	public static void main(String[] args) throws Exception {
		executeGetThroughProxy();

		executeGetThroughProxyWithCredentials();

		executeGetThroughProxyWithCredentialsInJersey();
	}

	private static void executeGetThroughProxy() throws Exception {
		OAuthConsumer consumer = new CommonsHttpOAuthConsumer(ConsumerKey, ConsumerSecret);
		consumer.setTokenWithSecret(AccessToken, AccessSecret);

		HttpGet request = new HttpGet(
				"https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=xxxx&count=2");

		consumer.sign(request);

		// Here you set your proxy host and port
		HttpHost proxy = new HttpHost("your_proxy_addess", 1234);
		DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
		HttpClient client = HttpClients.custom().setRoutePlanner(routePlanner).build();
		HttpResponse response = client.execute(request);

		String json_string = EntityUtils.toString(response.getEntity());
		System.out.println(json_string);
	}

	private static void executeGetThroughProxyWithCredentials() throws Exception {
		OAuthConsumer consumer = new CommonsHttpOAuthConsumer(ConsumerKey, ConsumerSecret);
		consumer.setTokenWithSecret(AccessToken, AccessSecret);

		HttpHost proxy = new HttpHost("your_proxy_addess", 1234);
		RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
		HttpGet request = new HttpGet(
				"https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=xxxx&count=2");
		request.setConfig(config);

		consumer.sign(request);

		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope("your_proxy_addess", 1234),
				new UsernamePasswordCredentials("user", "passwd"));

		HttpClient client = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();
		HttpResponse response = client.execute(request);

		String json_string = EntityUtils.toString(response.getEntity());
		System.out.println(json_string);
	}

	private static void executeGetThroughProxyWithCredentialsInJersey() {

		final ClientConfig config = new ClientConfig();
		config.property(ClientProperties.PROXY_URI, "http://www.proxy.com:9999");
		config.property(ClientProperties.PROXY_USERNAME, "proxyuser");
		config.property(ClientProperties.PROXY_PASSWORD, "proxypassword");
		config.connectorProvider(new ApacheConnectorProvider());
		final Client client = ClientBuilder.newClient(config);
		final HttpAuthenticationFeature authFeature = HttpAuthenticationFeature.basicBuilder().nonPreemptive()
				.credentials("user", "password").build();
		client.register(authFeature);
	}
}
