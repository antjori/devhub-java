package pt.devhub.mytests.stackoverflow.ejb;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class EJBCall {

	public static void main(String[] args) throws NamingException {
		// Let's lookup the remote stateless calculator
	    NewSessionBeanRemote remoteEjb = lookupRemoteSessionBean();
	    System.out.println("Obtained a remote stateless calculator for invocation");
	    String bookName = "TEST book";
	    remoteEjb.addBook(bookName);
	    System.out.println(remoteEjb.getBook());
	}

	private static NewSessionBeanRemote lookupRemoteSessionBean() throws NamingException {

	    final Hashtable<String, Object> jndiProperties = new Hashtable<>();
	    jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
	    jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
	    jndiProperties.put(Context.PROVIDER_URL, "http-remoting://127.0.0.1:8080");
	    //jndiProperties.put(Context.SECURITY_PRINCIPAL, "ejb"); //this is the application user name, not management! it's correct?
	    //jndiProperties.put(Context.SECURITY_CREDENTIALS, "ejb");//this is the application password, not management! it's correct?
	    jndiProperties.put("jboss.naming.client.ejb.context", true);
	    final Context context = new InitialContext(jndiProperties);
	    final String appName = "";
	    final String moduleName = "stackoverflow-0.0.1-SNAPSHOT/";
	    final String distinctName = "";
	    final String beanName = NewSessionBean.class.getSimpleName();
	    final String viewClassName = NewSessionBeanRemote.class.getName();
	    //System.out.println("ejb:" + appName + "/" + moduleName + "/" + distinctName + "/" + beanName + "!" + viewClassName);
	    //return (NewSessionBeanRemote) context.lookup("ejb:" + appName + "/" + moduleName + "/" + distinctName + "/" + beanName + "!" + viewClassName);
	    return (NewSessionBeanRemote) context.lookup(appName + moduleName + distinctName + beanName + "!" + viewClassName);
	}
}
