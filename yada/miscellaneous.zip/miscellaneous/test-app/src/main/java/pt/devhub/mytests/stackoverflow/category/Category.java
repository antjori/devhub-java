package pt.devhub.mytests.stackoverflow.category;

public class Category {

	// The category type
	private CategoryType categoryType;

	// The category value
	private int value;

	public Category(CategoryType categoryType, int value) {
		this.categoryType = categoryType;
		this.value = value;
	}

	public CategoryType getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(CategoryType categoryType) {
		this.categoryType = categoryType;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
}
