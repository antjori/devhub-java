package pt.devhub.mytests.stackoverflow.category;

import java.util.HashMap;
import java.util.Map;

public class Card {

	// Defines the best category (for later use)
	private CategoryType bestCategoryType;

	// Holds all categories, easily accessible by type
	private Map<CategoryType, Category> categories;

	public Card() {
		categories = new HashMap<>();
		// by default, the year of release will be the best category
		bestCategoryType = CategoryType.YEAR_OF_RELEASE;
	}

	public void createCategory(CategoryType categoryType, int value, boolean isBest) {
		createCategory(categoryType, value);

		if (isBest) {
			bestCategoryType = categoryType;
		}
	}

	public void createCategory(CategoryType categoryType, int value) {
		Category category = new Category(categoryType, value);
		categories.put(categoryType, category);
	}

	// Attains the best category
	public CategoryType getBestCategoryType() {
		return bestCategoryType;
	}

	// Attains the map of categories
	public Map<CategoryType, Category> getCategories() {
		return categories;
	}

}
