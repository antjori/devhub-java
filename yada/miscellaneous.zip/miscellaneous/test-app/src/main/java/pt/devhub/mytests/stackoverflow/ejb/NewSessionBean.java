package pt.devhub.mytests.stackoverflow.ejb;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;
import javax.ejb.Stateless;

@Stateless
@Remote(NewSessionBeanRemote.class)
public class NewSessionBean implements NewSessionBeanRemote {

	List<String> bookShielf;

	/**
	 * Default constructor.
	 */
	public NewSessionBean() {
		bookShielf = new ArrayList<String>();
	}

	@Override
	public void addBook(String bookName) {
		bookShielf.add(bookName);
	}

	@Override
	public List<String> getBook() {
		return bookShielf;
	}

}
