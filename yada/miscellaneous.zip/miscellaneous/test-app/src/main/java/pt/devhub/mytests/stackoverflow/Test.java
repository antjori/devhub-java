package pt.devhub.mytests.stackoverflow;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Test {

	private JFrame mainFrame;
	private JPanel panelX;
	private String test;

	public static void main(String[] args) {

		Test run = new Test();

		run.GUIinit();
		run.addButton();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(run.returnData()); // This returns null
	}

	public Test() { // Empty constructor
	}

	public String returnData() { // Method to return string value
		return test;
	}

	public void setData(String data) { // Method to set string value
		test = data;
	}

	private void GUIinit() {
		mainFrame = new JFrame("Text");
		mainFrame.setSize(200, 200);
		mainFrame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent windowEvent) {
				System.exit(0);
			}
		});

		panelX = new JPanel();
		mainFrame.add(panelX);

		mainFrame.setVisible(true);
	}

	private void addButton() { // Problematic part

		JButton testButton = new JButton("Text");
		panelX.add(testButton);

		testButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setData("STRING BLABLA");
				System.out.println(returnData());
			}
		});
	}
}
