package pt.devhub.mytests.stackoverflow.rest;

import java.io.FileInputStream;
import java.io.InputStream;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;

import org.restlet.data.MediaType;
import org.restlet.data.Status;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.restlet.resource.Post;
import org.restlet.resource.ResourceException;
import org.restlet.resource.ServerResource;

public class RestletExample extends ServerResource {

	public static void main(String[] args) {
		RestletExample example = new RestletExample();
		Representation response = example.post(new StringRepresentation("example"));
		System.out.println(response);
	}

	@Override
	@Post("JSON")
	public Representation post(Representation entity) throws ResourceException {
		JsonObjectBuilder response = Json.createObjectBuilder();

		try {
			if (entity.getMediaType().isCompatible(MediaType.APPLICATION_JSON)) {

				// Read JSON file and parse onto local variables
				// FileReader fr = new
				// FileReader(getClass().getResource("/input.json").getFile());
				// JsonReader reader = Json.createReader(fr);

				InputStream is = new FileInputStream(getClass().getResource("/input.json").getFile());

				try (JsonReader reader = Json.createReader(is)) {
					JsonObject obj = reader.readObject();

					// retrieve JSON contents
					int campaingID = obj.getInt("campaignID");
					System.out.println(campaingID);
					int clientID = obj.getInt("clientID");
					System.out.println(clientID);
					int pmapID = obj.getInt("pmapID");
					System.out.println(pmapID);
					String ward = obj.getString("ward");
					System.out.println(ward);
					int age = obj.getInt("age");
					System.out.println(age);
					String attr1 = obj.getString("attr1");
					System.out.println(attr1);
					String attr2 = obj.getString("attr2");
					System.out.println(attr2);
					String attr3 = obj.getString("attr3");
					System.out.println(attr3);
					String attr4 = obj.getString("attr4");
					System.out.println(attr4);
					String attr5 = obj.getString("attr5");
					System.out.println(attr5);
					String attr6 = obj.getString("attr6");
					System.out.println(attr6);
				}

				// Do processing & return a float value
				response.add("PMC", 30.12);

			}
		} catch (Exception e) {
			e.printStackTrace();
			getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
		}

		return new StringRepresentation(response.build().toString());
	}
}
