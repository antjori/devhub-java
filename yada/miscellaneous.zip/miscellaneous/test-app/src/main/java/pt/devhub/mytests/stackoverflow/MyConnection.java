package pt.devhub.mytests.stackoverflow;

import java.sql.Connection;
import java.sql.DriverManager;

public class MyConnection {

	public Connection getConnection() {
		Connection connection = null;

		try {
			Class.forName("org.sqlite.JDBC");
			connection = DriverManager.getConnection("jdbc:sqlite:");
			System.out.println("Connection completed.");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return connection;
	}
}
