package pt.devhub.mytests.stackoverflow;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Main {

	public static void main(String[] args) {
		// checkListContent();

		// parseArguments(args);

		// callRestfulService();

		// convertChar(args);

		// loadProperties();

		// listIterator();

		// accessJNDI();

		// reverseSort();

		// doLookUp();

		// regex();

		// formatDate();

		// callFtp();

		// executePhantomJs();

		// deleteDashboard();

		// jsonToPojo();

		// encodeBitwise();

		// testObjectChange();

		dateParsingJava8();
	}

	public static boolean set(Object object, String fieldName, Object fieldValue) {
		Class<?> clazz = object.getClass();
		while (clazz != null) {
			try {
				Field field = clazz.getDeclaredField(fieldName);
				field.setAccessible(true);
				field.set(object, fieldValue);
				return true;
			} catch (NoSuchFieldException e) {
				clazz = clazz.getSuperclass();
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
		}
		return false;
	}

	public static final void checkListContent() {
		List<String> stringList = new ArrayList<>();

		stringList.add("Cash on hand -4871266");
		stringList.add("SB Account 976369");
		stringList.add("Current Account 980980");

		for (String str : stringList) {
			// Extracts the left hand-side of your string
			System.out.println(str.replaceAll("[\\s-+][0-9]+", ""));
			// Extracts the right hand-side of your string
			Pattern testPattern = Pattern.compile("[\\s-+][0-9]+");
			Matcher matcher = testPattern.matcher(str);
			matcher.find();
			System.out.println(matcher.group().trim());
		}
	}

	public static final void parseArguments(final String[] args) {
		boolean isTrailingActive = false;
		boolean isEscapingActive = false;
		String inputStr;
		int index = 0;

		// Validates the amount of arguments passed to Echo
		if (args.length == 0 || args.length > 3) {
			return;
		}

		while (index < args.length - 1) {
			// Validates trailing active
			if (args[index].equals("-n")) {
				isTrailingActive = true;
				index++;
			}

			// Validates escaping active
			if (args[index].equals("-e")) {
				isEscapingActive = true;
				index++;
			}
		}

		while (index < args.length) {
			inputStr = args[index];

			if (isEscapingActive) {
				inputStr = inputStr.replace("\\t", "\t").replace("\\n", "\n");
			}

			if (isTrailingActive) {
				System.out.print(inputStr);
			} else {
				System.out.println(inputStr);
			}

			index++;
		}
	}

	public static final void parseArgumentsSIDA(final String[] args) {
		boolean hasE = false;
		boolean hasN = false;
		String message = args[args.length - 1];

		for (int i = args.length - 2; i >= 0; i--) {
			switch (args[i]) {
			case "-n":
				hasN = true;
				break;
			case "-e":
				hasE = true;
				break;
			}
		}

		if (hasE)
			message = message.replace("\\n", "\n").replace("\\t", "\t");
		if (hasN)
			System.out.print(message);
		else
			System.out.println(message);
		System.out.println("Test");
	}

	public static final void callRestfulService() {
		// doGet();
		// doPost();
		// getDashboard();
	}

	protected static final void getDashboard() {

		Client client = ClientBuilder.newClient().register(new ClientRequestFilter() {

			@Override
			public void filter(ClientRequestContext requestContext) throws IOException {
				requestContext.getHeaders().add(HttpHeaders.AUTHORIZATION, getBasicAuthentication());
			}

			private String getBasicAuthentication() throws UnsupportedEncodingException {
				String userAndPassword = "admin:hubble_monitoring";
				byte[] userAndPasswordBytes = userAndPassword.getBytes("UTF-8");
				// Java 1.8: Base64.getEncoder().encodeToString
				return "Basic " + java.util.Base64.getEncoder().encodeToString(userAndPasswordBytes);
			}
		});

		WebTarget target = client.target("http://testv0085.fr.net.intra:3000/api" + "/dashboards/db/" + "my-dashboard");
		Response response = target.request().get();
		final String dashboardJsonRaw = response.readEntity(String.class);
		response.close();
		System.out.println(dashboardJsonRaw);
	}

	protected static final void callFtp() {

		// WebTarget target =
		// client.target("http://testv0086:3000/render/dashboard-solo/db/test-dashboard?panelId=8");

		FTPClient ftpClient = new FTPClient();

		try {
			ftpClient.connect("testv0086", 3000);
			ftpClient.login("admin", "admin");
			ftpClient.enterLocalPassiveMode();
			ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

			// APPROACH #1: using retrieveFile(String, OutputStream)
			String remoteFile1 = "/render/dashboard-solo/db/test-dashboard?panelId=8";
			File downloadFile1 = new File("C:\\Users\\a74659\\Desktop\\poiouiyt.png");
			OutputStream outputStream1 = new BufferedOutputStream(new FileOutputStream(downloadFile1));
			boolean success = ftpClient.retrieveFile(remoteFile1, outputStream1);
			outputStream1.close();

			if (success) {
				System.out.println("File #1 has been downloaded successfully.");
			}

			// APPROACH #2: using InputStream retrieveFileStream(String)
			String remoteFile2 = "/render/dashboard-solo/db/test-dashboard?panelId=8";
			File downloadFile2 = new File("C:\\Users\\a74659\\Desktop\\poiouiyt2.png");
			OutputStream outputStream2 = new BufferedOutputStream(new FileOutputStream(downloadFile2));
			InputStream inputStream = ftpClient.retrieveFileStream(remoteFile2);
			byte[] bytesArray = new byte[4096];
			int bytesRead = -1;
			while ((bytesRead = inputStream.read(bytesArray)) != -1) {
				outputStream2.write(bytesArray, 0, bytesRead);
			}

			success = ftpClient.completePendingCommand();
			if (success) {
				System.out.println("File #2 has been downloaded successfully.");
			}
			outputStream2.close();
			inputStream.close();
		} catch (Exception e) {

		} finally {
			try {
				if (ftpClient.isConnected()) {
					ftpClient.logout();
					ftpClient.disconnect();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	protected static final void doGet() {
		try {
			HttpClient client = HttpClientBuilder.create().build();

			HttpGet request = new HttpGet("http://localhost:8080/hubble-map/rest/service/load");

			HttpResponse response = client.execute(request);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}

			String output = EntityUtils.toString(response.getEntity(), "utf-8");

			System.out.println("Output from Server .... \n");
			System.out.println(output);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected static final void doPost() {
		try {
			HttpClient client = HttpClientBuilder.create().build();

			HttpPost request = new HttpPost("http://localhost:8080/hubble-map/rest/service/save");
			/*
			 * List<NameValuePair> nvps = new ArrayList<>(); nvps.add(new
			 * BasicNameValuePair("map", "executing post operation"));
			 * request.setEntity(new UrlEncodedFormEntity(nvps));
			 */
			request.setEntity(new StringEntity("{ \"user_id\" : \"123456\", \"groups\" : [], \"favorites\" : [] }"));
			/*
			 * UsernamePasswordCredentials creds = new
			 * UsernamePasswordCredentials("John", "pass");
			 * request.addHeader(new BasicScheme().authenticate(creds, request,
			 * null));
			 */
			request.setHeader("Accept", MediaType.APPLICATION_JSON);
			request.setHeader("Content-type", MediaType.APPLICATION_JSON);

			HttpResponse response = client.execute(request);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}

			String output = EntityUtils.toString(response.getEntity(), "utf-8");

			System.out.println("Output from Server .... \n");
			System.out.println(output);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static final void convertChar(String[] args) {
		System.out.println(args[0]);
	}

	public static final void loadProperties() {
		MyClass.init();
	}

	public static void listIterator() {
		Map<String, Integer> mySet = new LinkedHashMap<>();
		List<Entry<String, Integer>> myList = new ArrayList<>(mySet.entrySet());
		ListIterator<Entry<String, Integer>> myListIterator = myList.listIterator();

		while (myListIterator.hasNext()) {
			System.out.println(myListIterator.next());
		}
	}

	public static void accessJNDI() {
		Context context = null;
		Properties prop = new Properties();
		prop.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
		prop.put(Context.PROVIDER_URL, System.getProperty(Context.PROVIDER_URL, "remote://localhost:8181"));
		prop.put("jboss.naming.client.ejb.context", true);

		try {
			context = new InitialContext(prop);
		} catch (NamingException e) {
			e.printStackTrace();
		}

		if (context != null) {
			System.out.println("Context not null...");
		}
	}

	public static void reverseSort() {
		Integer[] array = { 2, 6, 4, 1 };
		Arrays.sort(array, Collections.reverseOrder());
		for (int num : array) {
			System.out.println(num);
		}
	}

	public static void doLookUp() {
		final Hashtable<String, Object> jndiProperties = new Hashtable<>();
		jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
		jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
		jndiProperties.put(Context.PROVIDER_URL, "http-remoting://127.0.0.1:8080");
		jndiProperties.put("jboss.naming.client.ejb.context", true);

		try {
			final Context context = new InitialContext(jndiProperties);

			Object object = context.lookup("java:/url/SSOService");
			System.out.println(object);
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void regex() {
		Pattern pattern = Pattern.compile("(?<=//).*(?=/)");
		Matcher matcher = pattern.matcher("jdbc:jtds:sybase://10.186.80.25:5000/master;socketTimeout=500");

		if (matcher.find()) {
			System.out.println(matcher.replaceFirst("tiths306:5544"));
		}

		System.out.println(String.format("jdbc:jtds:sybase://%1s:%2s/master;socketTimeout=500", "tiths306", "5544"));

		// In Elasticsearch we should use "Type:="
		// The ":" provides better accuracy in the query
		pattern = Pattern.compile("(?<=Type=\").*(?=\")");
		matcher = pattern.matcher("Type=\"memory-memory-slab_recl\"");

		if (matcher.find()) {
			System.out.println(matcher.group());
		}

		String url = "/render/dashboard-solo/db/%s?from=now-15m&to=now&panelId=%d&width=1000&height=500";
		System.out.println(String.format(url, "testv0085_es", 8));

		System.out.println("testv0085".replaceAll("(?=_).*", ""));

		// network pattern
		pattern = Pattern.compile("(?<=interface-).*(?=-if_octets)");
		matcher = pattern.matcher("interface-intel[r] pro_1000 mt network connection-if_octets");

		if (matcher.find()) {
			System.out.println(matcher.group());
		}
	}

	public static void formatDate() {
		DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy/mm/dd hh:mm:ss");
		DateTime time = formatter.parseDateTime("2016/05/27 07:45:32");
		System.out.println(time);

		SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = null;
		try {
			date = formatter2.parse("2016/05/27 07:45:32");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (date != null)
			System.out.println(date);

		System.out.println(DateTime.parse("2016-06-23T20:07:51.000Z").toDate());

		DateTimeFormatter formatter3 = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		try {
			System.out.println(formatter3.parseDateTime("2016-06-23T20:07:51.000Z"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		try {
			System.out.println(formatter3.parseLocalDate("2016-06-23T20:07:51.000Z"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		try {
			System.out.println(formatter3.parseLocalDateTime("2016-06-23T20:07:51.000Z"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		try {
			System.out.println(formatter3.parseLocalTime("2016-06-23T20:07:51.000Z"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		try {
			System.out.println(formatter3.parseMillis("2016-06-23T20:07:51.000Z"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		DateTimeFormatter dtf = DateTimeFormat.forPattern("EEEE, MMM dd YYYY 'at' HH:mm:ss.SSS");

		System.out.println(dtf.print(Calendar.getInstance().getTimeInMillis()));

		Date date1 = DateTime.parse("2016-08-05T12:33:35.466Z").toLocalDateTime().toDate();

		DateTime dt1 = new DateTime(date1);
		System.out.println(dt1);
		System.out.println(dt1.minusMinutes(5).toDate());
		System.out.println(dt1.minusMinutes(5).toDate().getTime());

		LocalDateTime ldt1 = dt1.toLocalDateTime();
		System.out.println(ldt1);
		System.out.println(ldt1.minusMinutes(5).toDate());
		System.out.println(ldt1.minusMinutes(5).toDate().getTime());
	}

	public static void executePhantomJs() {
		ClientBuilder.newClient().register(new ClientRequestFilter() {

			@Override
			public void filter(ClientRequestContext requestContext) throws IOException {
				requestContext.getHeaders().add(HttpHeaders.AUTHORIZATION, getBasicAuthentication());
			}

			private String getBasicAuthentication() throws UnsupportedEncodingException {
				String userAndPassword = "admin:hubble_monitoring";

				byte[] userAndPasswordBytes = userAndPassword.getBytes("UTF-8");
				// Java 1.7: com.google.common.io.BaseEncoding.base64().encode
				// Java 1.8: Base64.getEncoder().encodeToString
				return "Basic " + Base64.getEncoder().encodeToString(userAndPasswordBytes);
			}
		}).target("http://testv0085.fr.net.intra:8080/hubble-map/graph/api/user/using/1").request().post(null);

		String command = "C:\\bp2s\\work\\tools\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe C:\\bp2s\\work\\tools\\phantomjs-2.1.1-windows\\examples\\rasterize.js ";
		String url = "http://testv0085.fr.net.intra:8080/hubble-map/graph/dashboard/db/testv0085?from=now-5m&to=now&panelId=8&fullscreen ";
		String imageOutput = "C:\\Users\\a74659\\Desktop\\test.png";

		System.out.println(command + url + imageOutput);

		Process process = null;

		try {
			process = Runtime.getRuntime().exec(command + url + imageOutput);

			process.waitFor();
			final int exitValue = process.waitFor();
			if (exitValue == 0) {
				System.out.println("Successfully executed the command: " + command);
			} else {
				System.out.println(
						"Failed to execute the following command: " + command + " due to the following error(s):");
				try (final BufferedReader b = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
					String line;
					if ((line = b.readLine()) != null)
						System.out.println(line);
				} catch (final IOException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void deleteDashboard() {
		Response response = ClientBuilder.newClient().register(new ClientRequestFilter() {

			@Override
			public void filter(ClientRequestContext requestContext) throws IOException {
				requestContext.getHeaders().add(HttpHeaders.AUTHORIZATION, getBasicAuthentication());
			}

			private String getBasicAuthentication() throws UnsupportedEncodingException {
				String userAndPassword = "admin:hubble_monitoring";

				byte[] userAndPasswordBytes = userAndPassword.getBytes("UTF-8");
				// Java 1.7: com.google.common.io.BaseEncoding.base64().encode
				// Java 1.8: Base64.getEncoder().encodeToString
				return "Basic " + Base64.getEncoder().encodeToString(userAndPasswordBytes);
			}
		}).target("http://s00vl9947945.fr.net.intra:3100/api/dashboards/db").request()
				.post(Entity.entity("{\"dashboard\": {\"id\": 16, \"title\": \"Yada\" }, \"overwrite\": true }",
						MediaType.APPLICATION_JSON));

		System.out.println(response.getStatus() + " - " + response.getStatusInfo().getReasonPhrase());
	}

	public static void jsonToPojo() {
		String server = "{ \"_id\" : { \"$oid\" : \"5731da862e0b37a3e3abd21c\" }, \"id\" : \"1\", \"name\" : \"testv0085\", \"full_name\" : \"testv0085.fr.net.intra\", \"os\" : \"LINUX\" }";

		ObjectMapper objectMapper = new ObjectMapper();

		HubbleServer hubbleServer = null;
		try {
			hubbleServer = objectMapper.readValue(server, HubbleServer.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(hubbleServer);
	}

	public static void encodeBitwise() {
		int result = 0;

		result |= 1 << 0;

		System.out.println(result);

		System.out.println("Is 001 set? " + ((result & (1 << 0)) != 0));

		result |= 1 << 1;

		System.out.println(result);

		System.out.println("Is 010 set? " + ((result & (1 << 1)) != 0));

		result |= 1 << 2;

		System.out.println(result);

		System.out.println("Is 100 set? " + ((result & (1 << 2)) != 0));

	}

	public enum AlertType {

		DESKTOP(2), EMAIL(4), SMS(8);

		private int value;

		/**
		 * Default enumeration constructor.
		 *
		 * @param value
		 *            the enumeration value;
		 */
		private AlertType(final int value) {
			this.setValue(value);
		}

		/**
		 * @return the value
		 */
		public int getValue() {
			return value;
		}

		/**
		 * @param value
		 *            the value to set
		 */
		public void setValue(int value) {
			this.value = value;
		}
	}

	private static void testObjectChange() {
		MyObject myObject = new MyObject();

		doChange(myObject);

		System.out.println(myObject.getMyList().size());
	}

	private static void doChange(final MyObject myObject) {
		myObject.getMyList().clear();

		myObject.getMyList().add("yada");
		myObject.getMyList().add("yada yada");
		myObject.getMyList().add("other yada");
	}

	private static void dateParsingJava8() {
		java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse("27/05/2016", formatter);

		java.sql.Date sqlDate = java.sql.Date.valueOf(date);

		System.out.println(sqlDate);
	}
}