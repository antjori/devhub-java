package pt.devhub.mytests.stackoverflow.ejb;

import java.util.List;

public interface NewSessionBeanRemote {

	public void addBook(String bookName);

	public List<String> getBook();
}
