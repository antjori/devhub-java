package pt.devhub.mytests.stackoverflow;

public enum MyEnum {

	UserContext("userContext", new String[] { "userURI" }), Level0and1ForUser("level0and1ForUser",
			new String[] { "userURI" });

	private String serviceName;
	private String[] requiredParameters;

	private MyEnum(String serviceName, String[] requriedParameters) {
		this.serviceName = serviceName;
		this.requiredParameters = requriedParameters;
	}

	public String getValue() {
		return serviceName;
	}

	public String[] getRequiredParameters() {
		return this.requiredParameters;
	}
}
