package pt.devhub.mytests.stackoverflow;

import java.util.ArrayList;
import java.util.List;

public class MyObject {

	private List<String> myList;

	public MyObject() {
		myList = new ArrayList<>();

		myList.add("a string");
		myList.add("some string");
	}

	/**
	 * @return the myList
	 */
	public List<String> getMyList() {
		return myList;
	}

	/**
	 * @param myList
	 *            the myList to set
	 */
	public void setMyList(List<String> myList) {
		this.myList = myList;
	}
}
