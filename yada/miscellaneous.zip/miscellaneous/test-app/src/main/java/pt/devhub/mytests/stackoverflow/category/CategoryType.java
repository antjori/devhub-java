package pt.devhub.mytests.stackoverflow.category;

public enum CategoryType {

	YEAR_OF_RELEASE,
	RAM_SIZE,
	CPU_SPEED,
	NUMBER_GAMES,
	GEEK_FACTOR;
}
