package pt.devhub.mytests.stackoverflow;

/**
 * Enumeration that represents the possible architectures' systems.
 */
public enum SystemType {

	UNIX("unix"), LINUX("linux"), WINDOWS("windows"), MULTI_OS("multi_os");

	private String system;

	private SystemType(final String system) {
		this.system = system;
	}

	/**
	 * @return the system
	 */
	public String getSystem() {
		return system;
	}

	/**
	 * @param system
	 *            the system to set
	 */
	public void setSystem(String system) {
		this.system = system;
	}

}
