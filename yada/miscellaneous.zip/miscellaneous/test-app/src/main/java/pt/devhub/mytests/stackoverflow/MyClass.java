package pt.devhub.mytests.stackoverflow;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class MyClass {

	public static void init() {
		InputStream input = MyClass.class.getClass().getResourceAsStream("/example.properties");
		Properties prop = new Properties();
		try {
			prop.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
