package pt.devhub.mytests.stackoverflow.category;

import java.util.ArrayList;
import java.util.List;

public class TopTrumps {

	public static void main(String[] args) {
		// list of cards per user
		List<Card> cards = new ArrayList<>();

		Card card1 = new Card();
		card1.createCategory(CategoryType.YEAR_OF_RELEASE, 1995);
		card1.createCategory(CategoryType.RAM_SIZE, 128);
		card1.createCategory(CategoryType.CPU_SPEED, 300);
		card1.createCategory(CategoryType.NUMBER_GAMES, 1000);
		// for card #1, the geek factor will be the best category
		card1.createCategory(CategoryType.GEEK_FACTOR, 7, true);

		// for card #2, since the best category, by default, is the year of
		// release, we'll leave it as it is
		Card card2 = new Card();
		card2.createCategory(CategoryType.YEAR_OF_RELEASE, 2005);
		card2.createCategory(CategoryType.RAM_SIZE, 256);
		card2.createCategory(CategoryType.CPU_SPEED, 500);
		card2.createCategory(CategoryType.NUMBER_GAMES, 750);
		card2.createCategory(CategoryType.GEEK_FACTOR, 4);

		// we'll add each card to our list
		cards.add(card1);
		cards.add(card2);

		// then, in order to access each category, one could do the following
		for (Card card : cards) {
			// retrieve the best category
			Category bestCategory = card.getCategories().get(card.getBestCategoryType());

			System.out.println("Best category: " + bestCategory.getCategoryType() + "=" + bestCategory.getValue());

			System.out.println("Card categories: ");

			// retrieve each card's category value
			for (Category category : card.getCategories().values()) {
				System.out.println(category.getCategoryType() + "=" + category.getValue());
			}
		}
	}
}
