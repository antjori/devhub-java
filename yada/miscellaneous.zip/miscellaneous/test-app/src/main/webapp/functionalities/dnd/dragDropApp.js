'use strict';

var dragDropApp = angular.module('dragDropApp', []);

dragDropApp.controller('DragDropCtrl', function($scope) {

	$scope.items = {
		'item1' : {
			'id' : '1',
			'name' : 'item1'
		},
		'item2' : {
			'id' : '2',
			'name' : 'item2'
		},
		'item3' : {
			'id' : '3',
			'name' : 'item3'
		}
	};

	$scope.itemCount = {
		'item1' : {
			'count' : 0
		},
		'item2' : {
			'count' : 0
		},
		'item3' : {
			'count' : 0
		}
	};

	$scope.handleDrop = function(itemId, binId) {
		alert('Item ' + itemId + ' has been dropped on bin ' + binId);
	}

	$scope.updateItemCounter = function(itemId) {
		console.log(itemId);
		console.log($scope.itemCount[itemId]);
		console.log($scope.itemCount[itemId].count);
		$scope.itemCount[itemId].count++;
		console.log($scope.itemCount[itemId].count);
	}

	$scope.myHandleDrop = function(itemId) {
		return $scope.itemCount[itemId].count++;
	}
});

dragDropApp.directive('draggable', function() {
	return {
		restrict : 'A',
		link : function(scope, element) {
			// this gives us the native JS object
			var el = element[0];

			el.draggable = true;

			el.addEventListener('dragstart', function(e) {
				e.dataTransfer.effectAllowed = 'copy';
				e.dataTransfer.setData('Text', this.id);
				this.classList.add('drag');
				return false;
			}, false);

			el.addEventListener('dragend', function(e) {
				this.classList.remove('drag');
				return false;
			}, false);
		}
	}
});

dragDropApp.directive('droppable', function() {
	return {
		restrict : 'A',
		scope : {
			drop : '&', // parent
			bin : '=' // bi-directional scope
		},
		controller : 'DragDropCtrl',
		link : function(scope, element, attrs, DragDropCtrl) {
			// again we need the native object
			var el = element[0];

			el.addEventListener('dragover', function(e) {
				e.dataTransfer.dropEffect = 'copy';
				// allows us to drop
				if (e.preventDefault)
					e.preventDefault();

				this.classList.add('over');
				return false;
			}, false);

			el.addEventListener('dragenter', function(e) {
				this.classList.add('over');
				return false;
			}, false);

			el.addEventListener('dragleave', function(e) {
				this.classList.remove('over');
				return false;
			}, false);

			el.addEventListener('drop', function(e) {
				// Stops some browsers from redirecting.
				if (e.stopPropagation)
					e.stopPropagation();

				if (e.preventDefault)
					e.preventDefault();

				this.classList.remove('over');

				var binId = this.id;

				/*
				 * var item = document.getElementById(e.dataTransfer
				 * .getData('Text'));
				 */
				var item = document.getElementById(
						e.dataTransfer.getData('Text')).cloneNode(true);

				//DragDropCtrl.updateItemCounter(item.id);
				//scope.$parent.updateItemCounter(item.id);
				//console.log(scope.$parent.itemCount[item.id].count);

				var newId = -1;

				scope.$apply(function(scope) {
					var fn = scope.drop();
					if ('undefined' !== typeof fn) {
						console.log("Item with id " + item.id
								+ " dropped on bin with id " + binId);
						newId = fn(item.id)
						console.log(newId);
					}
				});

				item.id = item.id + newId;//(scope.$parent.itemCount[item.id].count++);

				this.appendChild(item);

				// call the drop passed drop function
				/*scope.$apply(function(scope) {
					var fn = scope.drop();
					if ('undefined' !== typeof fn) {
						console.log("Item with id " + item.id
								+ " dropped on bin with id " + binId);
						fn(item.id, binId);
					}
				});*/

				return false;
			}, false);
		}
	}
});