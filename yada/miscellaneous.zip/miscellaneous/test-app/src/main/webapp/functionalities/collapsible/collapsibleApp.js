'use strict';

var collapsibleApp = angular.module('collapsibleApp', [ 'ngAnimate' ]);

collapsibleApp.controller('CollapsibleCtrl', function($scope) {
	$scope.collapsed = false;
	$scope.collapsedClass = 'divLeftCollapsed';

	$scope.toggleVertical = function() {
		$scope.collapsed = !$scope.collapsed;
		$scope.collapsedClass = $scope.collapsed ? 'divLeftExpanded'
				: 'divLeftCollapsed';
	}
})