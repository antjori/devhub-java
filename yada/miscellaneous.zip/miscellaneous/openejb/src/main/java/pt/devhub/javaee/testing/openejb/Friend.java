package pt.devhub.javaee.testing.openejb;

import javax.ejb.Local;

@Local
public interface Friend {

    public String sayHello();

    public String helloFromFriend();

}
