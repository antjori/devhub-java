package pt.devhub.javaee.testing.openejb;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.ejb.Stateless;

@Stateless(name = "BlueBean")
//@EJB(beanInterface = Friend.class, beanName = "BlueBean", name = "myFriend")
public class BlueBean implements Friend {

	@EJB(mappedName = "RedBean")
	private Friend friend;
	
	@Override
	public String sayHello() {
		return "Blue says, Hello!";
	}

	@Override
	public String helloFromFriend() {
		try {
			//Friend friend = (Friend) new InitialContext().lookup("java:comp/env/myFriend");
			return "My friend " + friend.sayHello();
		} catch (Exception e) {
			throw new EJBException(e);
		}
	}
}
