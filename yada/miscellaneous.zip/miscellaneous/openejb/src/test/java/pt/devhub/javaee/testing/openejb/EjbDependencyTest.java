package pt.devhub.javaee.testing.openejb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;

import org.junit.BeforeClass;
import org.junit.Test;

public class EjbDependencyTest {

	private static Context context;

	@BeforeClass
	public static void setUp() throws Exception {
		context = EJBContainer.createEJBContainer().getContext();
	}

	@Test
	public void testRed() throws Exception {

		final Friend red = (Friend) context.lookup("java:global/openejb/RedBean");

		assertNotNull(red);
		assertEquals("Red says, Hello!", red.sayHello());
		assertEquals("My friend Blue says, Hello!", red.helloFromFriend());
	}

	@Test
	public void testBlue() throws Exception {

		final Friend blue = (Friend) context.lookup("java:global/openejb/BlueBean");

		assertNotNull(blue);
		assertEquals("Blue says, Hello!", blue.sayHello());
		assertEquals("My friend Red says, Hello!", blue.helloFromFriend());
	}
}
